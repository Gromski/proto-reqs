<template>
  <div class="p-4">
    <h1 class="text-2xl font-bold mb-4">Prototype to Requirements Tool</h1>
    <PrototypeViewer />
    <ElementInspector />
    <RequirementEditor />
    <ExportOptions />
  </div>
</template>

<script setup lang="ts">
import PrototypeViewer from './components/PrototypeViewer.vue'
import ElementInspector from './components/ElementInspector.vue'
import RequirementEditor from './components/RequirementEditor.vue'
import ExportOptions from './components/ExportOptions.vue'
</script>
