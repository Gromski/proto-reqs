import { defineStore } from 'pinia'

export const useRequirementsStore = defineStore('requirements', {
  state: () => ({
    screens: [] as Array<{
      name: string
      description: string
      elements: string[]
      questions: string[]
      notes: string
    }>
  }),
  actions: {
    addScreen(screen: any) {
      this.screens.push(screen)
    },
    updateScreen(index: number, updates: Partial<typeof this.screens[0]>) {
      Object.assign(this.screens[index], updates)
    }
  }
})
