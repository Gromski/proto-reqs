<template>
  <div>
    <h2 class="text-lg font-bold">Detected Elements</h2>
    <ul>
      <li v-for="el in elements" :key="el">{{ el }}</li>
    </ul>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'

const elements = ref<string[]>([])

onMounted(() => {
  // Placeholder logic
  elements.value = ['Button: Create Project', 'Graph: Unknown data', 'Form: Login']
})
</script>
