<template>
  <div v-for="(screen, i) in screens" :key="i" class="mb-4 p-4 border rounded">
    <input v-model="screen.name" placeholder="Screen name" class="input font-bold" />
    <textarea v-model="screen.description" placeholder="Description" class="textarea" />
    <textarea v-model="screen.notes" placeholder="Notes" class="textarea" />
    <ul>
      <li v-for="(q, qi) in screen.questions" :key="qi">
        <input v-model="screen.questions[qi]" class="input text-sm" />
      </li>
    </ul>
  </div>
</template>

<script setup lang="ts">
import { useRequirementsStore } from '../stores/requirementsStore'
const { screens } = useRequirementsStore()
</script>
