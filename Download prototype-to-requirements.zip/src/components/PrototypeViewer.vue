<template>
  <div>
    <label>Paste prototype URL:</label>
    <input v-model="url" placeholder="Figma or deployed URL" class="input" />
    <iframe v-if="url" :src="url" class="w-full h-[600px] mt-4 border" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
const url = ref('')
</script>
