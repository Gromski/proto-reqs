<template>
  <div class="mt-4">
    <button @click="exportMarkdown" class="btn">Export as Markdown</button>
  </div>
</template>

<script setup lang="ts">
import { useRequirementsStore } from '../stores/requirementsStore'

const { screens } = useRequirementsStore()

function exportMarkdown() {
  let md = '# Requirements\n\n'
  screens.forEach(screen => {
    md += `## ${screen.name}\n\n`
    md += `${screen.description}\n\n`
    if (screen.elements?.length) {
      md += `**Elements:**\n- ${screen.elements.join('\n- ')}\n\n`
    }
    if (screen.questions?.length) {
      md += `**Questions:**\n- ${screen.questions.join('\n- ')}\n\n`
    }
    if (screen.notes) {
      md += `**Notes:** ${screen.notes}\n\n`
    }
  })

  const blob = new Blob([md], { type: 'text/markdown' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = 'requirements.md'
  link.click()
}
</script>
